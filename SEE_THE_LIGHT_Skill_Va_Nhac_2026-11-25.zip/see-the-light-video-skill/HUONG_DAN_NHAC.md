# Nhạc nền đã kèm trong gói

File: `assets/music/fiction-vietz-remix.mp3` — bản MP3 đầy đủ FICTION – VIETZ REMIX người dùng đã cung cấp.

- Thời lượng: khoảng 2 phút 48,41 giây.
- Bắt đầu dùng từ 00:00 theo mẫu đã chốt.
- Gain nhạc khi mix: -17 dB so với bản gốc.
- File MP3 giữ nguyên dữ liệu và âm lượng gốc. Không giảm sẵn -17 dB rồi lại giảm tiếp khi mix.
- Không chuẩn hóa nhạc hoặc ducking; fade đầu 0,4 giây, cuối 1 giây.

Khi chạy từ thư mục gốc đã giải nén, đường dẫn `assets/music/fiction-vietz-remix.mp3` trong settings mẫu dùng được. Nếu chạy dự án ở nơi khác, đổi `background_music.file` sang đường dẫn tuyệt đối của file nhạc.

Sao chép settings mẫu vào `work/production/series-settings.json`, rồi thực hiện các bước trong SKILL.md. Các thiết lập còn lại và toàn bộ scripts/font/template vẫn có trong cùng ZIP.

SHA-256 MP3:
`96e4ea7d35b7bff48ec3d17eb2903e6ffda3800526c343c39743a2bbe0ae08ef`
