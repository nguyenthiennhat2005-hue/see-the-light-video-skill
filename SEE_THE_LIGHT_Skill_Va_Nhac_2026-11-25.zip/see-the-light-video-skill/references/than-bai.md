# Thân bài một mạch

Thân bài nối ngay sau hook, dài khoảng 100–125 tiếng (tổng cả bài dự toán **123–147 tiếng**, đo MP3 để chốt 25–30 giây).

## Vì sao phải "một mạch" (13-10)

Chủ kênh nghe MP3 bộ 2 và chê thân bài "cụt lủn mỗi câu không đầu không đuôi, nghe chán".

Nguyên nhân là brief cũ giao khuôn 7 ô (bối cảnh / chuyện / "ta hay…" / 2–3 ví dụ / "Câu này không bảo
bạn…" / "Tối nay hãy…" / câu kết). Người viết điền đúng từng ô, nên mỗi câu thành một ý rời. Thêm vào đó là
chi tiết tiểu sử kiểu thư mục (số bản sách, ai chép lại) và ví dụ liệt kê mỗi cảnh một câu.

Các bài thắng chỉ đi **một lập luận**. Câu sau mọc ra từ câu trước. Có đoạn giải thích VÌ SAO câu nói
đúng, ví dụ "Cái khó của chuyện khoe là…", "Ít ai để ý điều này:".

## Khuôn 6 bước (theo đúng thứ tự)

1. **Một câu bối cảnh**: ai nói, nói ở đâu, khi nào. Năm và số viết bằng chữ.
2. **Tối đa 1–2 chi tiết đời thật** của nhân vật dẫn vào ý (có nguồn). Không kể tiểu sử dài.
3. **Cơ chế**: vì sao câu nói đúng, chỗ người ta hay tự lừa mình.
4. **MỘT cảnh đời thường Việt kể trọn trong 2–3 câu**: nhận việc khó, được thăng chức, đón phản hồi,
   học kỹ năng, bỏ dở việc, nhận trách nhiệm. Cảnh có người, có hành động, có hậu quả. Không liệt kê nhiều cảnh mỗi cảnh một câu.
5. **Một câu cân bằng** tự nhiên ("Thành tích không có lỗi…", "Tay nghề vẫn là cái gốc…"), để câu nói
   không thành cực đoan.
6. **Câu kết** nối từ mạch, có dư âm, thường hai vế. Không chốt bằng lời khuyên kiểu poster.

## Cấm

- "Câu này không bảo bạn…", "Tối nay / Tuần này / Lần tới, hãy…", và mọi câu khuôn lặp lại giữa các bài.
- Thuật ngữ, từ Hán Việt nặng, câu dịch sát. Viết như người kể chuyện ngoài đời.
- Mẹo bán hàng, quản lý đội ngũ, đầu tư kỹ thuật. Đây là bộ phát triển bản thân, phải đánh vào chính
  người nghe (thói quen, cái tôi, nỗi sợ, cách tự lừa mình).
- Chữ số trong `body`. Số phải viết bằng chữ để Vbee đọc đúng.

## Mẹo tự kiểm

Che một câu bất kỳ. Nếu câu sau mất nghĩa thì mạch liền. Nếu không ảnh hưởng gì thì bài đang liệt kê,
phải viết lại.


Các bài mẫu hiện hành nằm ở `examples/40-kich-ban-da-duyet.json` tính từ thư mục skill. Không viết tình huống hôn nhân hoặc hàng xóm.
