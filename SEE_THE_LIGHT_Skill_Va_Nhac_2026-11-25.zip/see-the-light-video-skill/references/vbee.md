# Vbee Studio bằng computer use

Giọng đã chốt: **HN – Ngọc Huyền**, mã hiển thị/tham chiếu
`hn_female_ngochuyen_full_48k-fhg`, tốc độ **1.1x**, xuất MP3 không nhạc.
Vbee là dịch vụ trả phí; gói skill không kèm tài khoản hoặc điểm sử dụng.

1. Mở https://studio.vbee.vn/studio/text-to-speech bằng công cụ computer use.
   Dùng phiên đăng nhập của người dùng; khi thiếu đăng nhập/OTP, để họ hoàn thành.
2. Mở đúng bài đang làm. Đối chiếu `n`, nhân vật, tiêu đề với bộ đã duyệt.
   Dán bản `tts` đã có phiên âm và nhịp nghỉ. Không đổi hook đã duyệt.
3. Chọn đúng Ngọc Huyền và **1.1x**. Giao diện có thể trả về 1x khi tải lại,
   nên kiểm lại trước mỗi lần tạo. Không lấy giọng của tác vụ trước làm chuẩn.
4. Thiết lập nghỉ tham khảo: dấu chấm 0,2 s, dấu phẩy 0,1 s, chấm phẩy 0,15 s,
   xuống dòng 0,25 s. Bản TTS dùng các break sau hook 0,08 s, giữa câu
   0,05/0,1/0,08 s, trước câu cuối 0,12 s; tránh chồng quá nhiều khoảng nghỉ.
5. Tạo lời đọc, đợi trạng thái hoàn thành và nghe kiểm tên/đủ chữ. Với bộ mới,
   kiểm bài đầu trước khi tạo cả loạt. Ghi số ký tự/điểm Vbee từ giao diện thực tế.
6. Trước khi bấm “Tải xuống”, đăng ký sự kiện `download` trong công cụ CUA.
   Sau khi hoàn thành, lấy đường dẫn file tải. Nếu trình duyệt chặn, kiểm trạng thái
   download hoặc thử điều khiển tải chính thức khác của trang; không đọc token.
7. Sao chép vào `work/videoNN/voice.mp3`, đo bằng ffprobe. Đích **25–30 giây**.
   Tên riêng trong phụ đề vẫn dùng chữ gốc, ví dụ Chung Ju-yung, không chép phiên âm TTS.
8. Nếu lời đọc thực sự sai, giữ bản cũ trong thư mục revisions, tạo lại phần cần thiết
   hoặc bài hoàn chỉnh và căn từ/QA lại. Không sửa chữ phụ đề để che lỗi phát âm.

Không dùng helper JavaScript cũ dò Redux/network để lấy token. Không in, lưu hoặc
đưa thông tin đăng nhập vào gói công khai. Không giữ URL audio có chữ ký tạm thay file MP3;
link có thể hết hạn, phải tải ngay khi tạo xong.

Ước tính cũ 4,91 tiếng/giây chỉ giúp biên tập. Thời lượng đo từ MP3 mới là số chốt.
