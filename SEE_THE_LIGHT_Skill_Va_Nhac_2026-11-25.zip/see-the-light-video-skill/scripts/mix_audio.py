"""Mix narration and user-provided music using the current project settings.

python scripts/mix_audio.py work/videoNN/plan.json work/production/series-settings.json
"""
import argparse
import json
import math
from pathlib import Path
import shutil
import subprocess

import numpy as np
import soundfile as sf
from common import ffmpeg_bin, probe_duration
from render import loudnorm_filter


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan')
    parser.add_argument('settings')
    args = parser.parse_args()
    plan_path = Path(args.plan).resolve()
    folder = plan_path.parent
    plan = json.loads(plan_path.read_text(encoding='utf-8'))
    settings = json.loads(Path(args.settings).read_text(encoding='utf-8'))
    cfg = settings['background_music']
    music = Path(cfg['file']).expanduser().resolve()
    voice = Path(plan['audio']).expanduser()
    if not voice.is_absolute():
        voice = folder / voice
    assert music.is_file(), 'Provide the music file in background_music.file.'
    assert voice.is_file(), 'Narration audio is missing.'
    assert not cfg.get('ducking', False), 'This workflow does not enable ducking.'
    assert not cfg.get('normalization', False), 'This workflow preserves music gain.'
    start = float(cfg['start_seconds'])
    gain = float(cfg['gain_db'])
    duration = probe_duration(str(voice))
    assert start >= 0 and duration > 2
    ffmpeg = ffmpeg_bin()

    def run(arguments):
        return subprocess.run([ffmpeg, '-hide_banner', '-nostats', '-y'] + arguments,
                              capture_output=True, text=True, check=True)

    def stats(path):
        result = run(['-i', str(path), '-af', 'loudnorm=print_format=json', '-f', 'null', '-']).stderr
        return json.loads(result[result.rindex('{'):result.rindex('}') + 1])

    master = folder / 'voice-master.wav'
    reference = folder / 'music-reference.wav'
    stem = folder / 'music-stem.wav'
    raw_mix = folder / 'mix-before-limiter.wav'
    final_mix = folder / 'mix.wav'
    voice_filter = loudnorm_filter(str(voice))
    run(['-i', str(voice), '-af', voice_filter + ',aresample=48000,aformat=channel_layouts=mono',
         '-c:a', 'pcm_f32le', str(master)])
    run(['-ss', str(start), '-i', str(music), '-t', str(duration), '-ar', '48000', '-ac', '1',
         '-c:a', 'pcm_f32le', str(reference)])
    assert probe_duration(str(reference)) >= duration - .02, 'Music segment is too short.'
    fade_in = float(cfg.get('fade_in_seconds', .4))
    fade_out = float(cfg.get('fade_out_seconds', 1))
    assert 0 <= fade_in < duration and 0 < fade_out < duration
    run(['-i', str(reference), '-af',
         f'volume={gain}dB,afade=t=in:d={fade_in},afade=t=out:st={duration-fade_out}:d={fade_out}',
         '-c:a', 'pcm_f32le', str(stem)])
    run(['-i', str(master), '-i', str(stem), '-filter_complex',
         '[0:a][1:a]amix=inputs=2:duration=first:normalize=0[a]', '-map', '[a]',
         '-c:a', 'pcm_f32le', str(raw_mix)])
    limited = float(stats(raw_mix)['input_tp']) > -1.5
    if limited:
        run(['-i', str(raw_mix), '-af', 'alimiter=limit=0.831764:level=false:latency=true',
             '-c:a', 'pcm_f32le', str(final_mix)])
    else:
        shutil.copyfile(raw_mix, final_mix)
    ref, sr = sf.read(str(reference))
    played, _ = sf.read(str(stem))
    left = int(max(fade_in + .1, .5) * sr)
    right = min(len(ref), len(played), int((duration - fade_out - .1) * sr))
    assert right > left
    rms = lambda audio: float(np.sqrt(np.mean(audio[left:right] ** 2)))
    assert rms(ref) > 0, 'The selected music segment is silent.'
    measured_gain = 20 * math.log10(rms(played) / rms(ref))
    assert abs(measured_gain - gain) < .01
    plan.update(render_audio=str(final_mix), audio_mastered=True)
    plan_path.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
    info = {'music_gain_db': gain, 'measured_music_gain_db': measured_gain,
            'music_start_seconds': start, 'duration_seconds': duration,
            'music_normalization': False, 'ducking': False,
            'peak_limiter_used': limited, 'final_mix_loudness': stats(final_mix)}
    (folder / 'mix-info.json').write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(info, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
