"""Save a video after automated QA and manual contact-sheet inspection."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

import av


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('video')
    parser.add_argument('qa_log')
    parser.add_argument('settings')
    parser.add_argument('--script-number', required=True)
    args = parser.parse_args()
    video = Path(args.video).resolve()
    qa_file = Path(args.qa_log).resolve()
    qa = qa_file.read_text(encoding='utf-8')
    assert 'KẾT LUẬN: ĐẠT' in qa and 'KẾT LUẬN: CHƯA ĐẠT' not in qa
    drift = int(re.search(r'lệch tuyệt đối lớn nhất (\d+) ms', qa).group(1))
    assert drift <= 67
    with av.open(str(video)) as container:
        v = container.streams.video[0]
        a = container.streams.audio[0]
        assert (v.width, v.height) == (1080, 1920) and v.average_rate == 30
        assert v.codec_context.name == 'h264' and v.codec_context.profile == 'High'
        assert v.codec_context.format.name == 'yuv420p'
        assert a.codec_context.name == 'aac' and a.rate == 48000 and a.codec_context.channels == 1
        duration = container.duration / av.time_base
        assert 25 <= duration <= 30
    settings_file = Path(args.settings).resolve()
    settings = json.loads(settings_file.read_text(encoding='utf-8'))
    mix = json.loads((qa_file.parent / 'mix-info.json').read_text(encoding='utf-8'))
    music = settings['background_music']
    assert abs(mix['measured_music_gain_db'] - music['gain_db']) < .01
    assert mix['music_start_seconds'] == music['start_seconds']
    folder = Path(settings['output_directory']).expanduser().resolve()
    folder.mkdir(parents=True, exist_ok=True)
    saved = folder / video.name
    assert not saved.exists(), 'Preserve the previous saved version; this script does not overwrite.'
    shutil.copy2(video, saved)
    digest = sha(video)
    assert sha(saved) == digest
    record = {'status': 'complete', 'file': str(saved), 'saved_file': str(saved),
              'workspace_file': str(video), 'duration_seconds': duration,
              'music_gain_db': music['gain_db'], 'music_start_seconds': music['start_seconds'],
              'qa': 'ĐẠT', 'karaoke_max_deviation_ms': drift, 'sha256': digest}
    settings.setdefault('videos', {})[str(args.script_number)] = record
    settings_file.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
