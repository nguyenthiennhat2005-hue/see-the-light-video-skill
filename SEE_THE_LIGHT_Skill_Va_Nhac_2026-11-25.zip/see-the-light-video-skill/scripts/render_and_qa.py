"""Render and immediately run QA, preserving logs next to the plan."""
import argparse
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('plan')
    parser.add_argument('output')
    args = parser.parse_args()
    plan = Path(args.plan).resolve()
    output = Path(args.output).resolve()
    assert not output.exists(), 'Preserve the existing export before replacing it.'
    output.parent.mkdir(parents=True, exist_ok=True)
    scripts = Path(__file__).resolve().parent
    for name in ['render', 'qa']:
        log = plan.parent / (name + '.log')
        with log.open('w', encoding='utf-8') as stream:
            subprocess.run([sys.executable, str(scripts / (name + '.py')), str(plan), str(output)],
                           stdout=stream, stderr=subprocess.STDOUT, check=True)
        print(log.read_text(encoding='utf-8'))
    assert 'KẾT LUẬN: ĐẠT' in (plan.parent / 'qa.log').read_text(encoding='utf-8')
    print('Inspect the QA contact sheet before saving the final video.')


if __name__ == '__main__':
    main()
