---
name: see-the-light-video-skill
description: Viết kịch bản và dựng video dọc Bài học từ doanh nhân cho SEE THE LIGHT, từ câu nói có nguồn hoặc bài đã duyệt đến lời đọc Vbee, ảnh thật, phụ đề karaoke, nhạc nền và MP4 đã nghiệm thu. Dùng khi làm hoặc sửa video trong series này.
---

# SEE THE LIGHT — quy trình trọn bộ

Bản tổng hợp ngày 25-11-2026 từ hai skill `kich-ban-bai-hoc-vbee`,
`sansan-video-bai-hoc` và quy trình thực tế đã dùng cho bộ 40 bài.
Các lựa chọn mới bên dưới thay thế mặc định cũ 35–40 giây và mốc nhạc 30 giây.
Yêu cầu mới nhất của người dùng luôn được ưu tiên.

## Thiết lập đã chốt

- Video 25–30 giây, 1080 × 1920, 30 fps, H.264 High/yuv420p, AAC mono 48 kHz.
- Giọng Vbee **HN – Ngọc Huyền**, tốc độ **1.1x**; kiểm tra lại sau mỗi lần tải trang.
- Nội dung: phát triển nội tại, cuộc sống, thăng tiến sự nghiệp và tư duy công việc.
  Không dùng chuyện vợ chồng, hôn nhân, hàng xóm/láng giềng. Tình huống công việc
  phải dẫn về nhận thức, năng lực hoặc trách nhiệm của chính người nghe.
- Hook tách thành một đoạn riêng trong bản duyệt. Giữ nguyên câu đã được duyệt.
- Nhạc **FICTION – VIETZ REMIX**, bắt đầu **00:00**, gain **−17 dB so với file gốc**,
  không chuẩn hóa nhạc, không ducking; fade đầu 0,4 giây, cuối 1 giây.
  Mẫu đã chốt: https://www.facebook.com/share/r/1EU1ThH1SW/.
- Đọc `work/production/series-settings.json` trước khi mix và xuất. Khởi tạo từ
  `config/series-settings.example.json` nếu dự án mới; mở rộng `~` thành thư mục người dùng.
- Lưu MP4 cuối vào **`~/Downloads/SEE THE LIGHT - Video`** sau khi QA đạt.
  Bản phát trong chat có thể nằm ở `outputs/`; file trung gian nằm trong `work/`.

## Chọn đúng điểm bắt đầu

- Người dùng yêu cầu video số N: tìm đúng `n` trong bộ kịch bản đang làm,
  không viết lại bài đã duyệt hoặc lấy nhầm bộ khác cùng số. Bộ hiện tại ở
  `examples/40-kich-ban-da-duyet.json`.
- Có MP3: bỏ bước viết và tạo giọng, bắt đầu bóc lời; âm thanh thực tế quyết định phụ đề.
- Viết bộ mới: thực hiện phần viết, duyệt hook trước, rồi viết thân bài và duyệt lời đọc.
  Lệnh “tạo video cho kịch bản N” trên bài đã duyệt là lệnh tạo giọng và dựng bài đó;
  không xin duyệt lại từng bước đã có lựa chọn.

## 1. Câu nói, hook và kịch bản

Đọc `references/gu-hook.md`, `references/viet-hoa-cau-noi.md`,
`references/nhan-vat.md` và `references/than-bai.md` khi viết mới.
Danh sách nhân vật trong tài liệu là gu biên tập lịch sử; thông tin về người đang sống
hoặc sự kiện mới phải kiểm chứng lại, không coi nhận định cũ là dữ kiện hiện tại.

1. Chọn doanh nhân nổi tiếng mà khán giả Việt Nam biết tên. Mỗi người tối đa hai bài/bộ,
   trừ khi người dùng chọn khác. Soát `data/loai_tru.txt` và các hook hiện tại để tránh trùng ý.
2. Xác minh câu nói bằng bài phát biểu, sách, phỏng vấn, tài liệu của doanh nghiệp hoặc
   nguồn báo chí đáng tin có ngữ cảnh/ngày. Không gán tên từ trang quote hoặc ảnh quote.
3. Việt hóa để đọc một lần là hiểu; ghi nguyên văn ngắn, URL và phần diễn ý trong `doi`.
   Phân biệt nguyên văn, dịch và diễn ý. Không tự viết “X từng nói” nếu không có nguồn.
4. Xuất danh sách hook dễ duyệt, mỗi hook riêng một dòng/đoạn. Đợi duyệt nếu là bộ mới;
   tôn trọng các sửa đổi đã duyệt, chẳng hạn bài 7 dùng “chưa chắc”.
5. Thân bài đi theo một lập luận: bối cảnh ngắn → cơ chế tâm lý → một tình huống công việc
   có hành động/hậu quả → một câu cân bằng → kết có dư âm. Không liệt kê lời khuyên.
   Ví dụ biên soạn phải được ghi là minh họa, không biến thành tiểu sử của nhân vật.
6. Tổng khoảng **123–147 tiếng đọc** ở 4,91 tiếng/giây là dự toán, không phải bảo đảm.
   Đo MP3 thật để chốt 25–30 giây. Không kéo tốc độ hoặc bỏ chữ của bài đã duyệt để ép thời lượng.
7. `scripts/dung_bo.py <thư_mục> <tên-bộ> --chi-hook` xuất trang hook;
   bỏ `--chi-hook` để xuất JSON, TTS và trang đầy đủ. Script báo vấn đề để biên tập soát,
   không tự sửa câu đã duyệt. Trường bài: `n, who, title, h, body, nguon, url, goc, doi`.

## 2. Tạo giọng Vbee qua giao diện

Đọc `references/vbee.md`. Dùng computer use trên Vbee Studio đã đăng nhập;
nếu cần đăng nhập thì để người dùng hoàn thành. Không xuất token, cookie hoặc mật khẩu.

- Hiển thị tên đúng chính tả gốc trong kịch bản, nhưng dùng phiên âm phù hợp trong TTS,
  theo `data/phien_am.json`; số trong bản đọc viết bằng chữ.
- Dùng đúng Ngọc Huyền 1.1x, MP3 không nhạc. Nhịp thêm sau hook 0,08 s,
  giữa câu khoảng 0,05/0,1/0,08 s, trước câu cuối 0,12 s.
- Bài mới tạo thử một bài trước khi chạy cả bộ. Kiểm tra tên riêng, giọng, đủ chữ, thời lượng.
  Khi đã có lời và yêu cầu tạo video thì tiếp tục dựng; không dừng ở MP3.
- Đăng ký sự kiện tải xuống trước khi bấm “Tải xuống”; tải ngay, không giữ URL ký tạm
  làm tài nguyên lâu dài. Lưu thành `work/videoNN/voice.mp3`, ghi giọng/tốc độ/điểm dùng.

## 3. Bóc lời và căn từng từ

Đọc `references/dung-video-chi-tiet.md` khi thao tác với pipeline và tên/số phiên âm.
Chạy tuần tự tác vụ nặng trên máy 8 GB:

```bash
python scripts/transcribe.py work/videoNN/voice.mp3 work/videoNN/asr.json small
python scripts/align.py work/videoNN/voice.mp3 work/videoNN/script.txt work/videoNN/words.json
```

Giữa hai lệnh phải soát lời nháp, phục hồi đoạn bị bỏ sót và tạo `script.txt` mỗi câu một dòng.
Lấy bài đã duyệt làm chuẩn để sửa lỗi nhận dạng, nhưng không thêm từ âm thanh không nói.
Tên hiển thị/âm đọc: `Ju-yung{giu_dung}`; số: `1990{một_nghìn_chín_trăm_chín_mươi}`.
Soát từ CTC điểm dưới −1,5 và chênh lệch với bản nghe độc lập. Phiên âm tên và gi/d/r có thể
giải thích được; trường hợp còn nghi phải nghe đoạn đó hoặc thử phương án và so điểm,
không xóa cảnh báo để cho qua. Không dùng timestamp Whisper cho karaoke.

## 4. Lập kế hoạch, hook và phụ đề

Khởi tạo `config.json` theo `examples/config.example.json`, ảnh có thể để trống ở lượt đầu:

```bash
python scripts/plan.py work/videoNN/words.json work/videoNN/config.json work/videoNN/plan.json
```

- Số ảnh là một hook + đúng số shot thực tế, không cố định theo số câu hoặc video trước.
- Hook nền đỏ, ribbon **TƯ DUY / SEE THE LIGHT**, nhãn **BÀI HỌC TỪ X:**.
  Chữ trắng 50 px, bề rộng tối đa 960 px. Lấp dòng tự nhiên, không tách từ ghép/tên,
  không để một dòng 2–3 chữ mồ côi. Dùng `do_tieu_de.py` đo phương án khi cần.
- `headline_lines` là ngoại lệ khi bản tự chia xấu; không thu nhỏ font để nhét chữ.
  Bộ hiện tại dùng hook không ngoặc kép. Không thêm CTA/logo/lời ngoài bản duyệt.
- Phụ đề một dòng IN HOA, Inter Bold 37 px, trắng → vàng #FFD400, không hộp nền.
  Mỗi cụm thường 4–6 tiếng, tối đa 7, không vắt qua dấu chấm.
  Không cắt đôi từ ghép/tên/số + đơn vị; tránh cụm kết bằng “của, một, chiếc…” hoặc
  bắt đầu bằng “hơn, nhất…” dính với cụm trước. Hạn chế cụm dưới 0,5 giây.
- Đọc và sửa từng `sub_chunks`, rồi chạy lại plan trước khi đếm ảnh. Không chia đều
  thời gian các từ: dùng đúng mốc CTC, kiểm karaoke trên video thật.

## 5. Ảnh và chuyển động

Đọc `references/chon-anh.md`; thông số ở `references/thong-so-thiet-ke.md` và `scripts/common.py`.

- Ảnh thật đúng người, **ít nhất 80% shot thân có nhân vật rõ mặt**; shot đầu/cuối có người.
  Phần còn lại gắn trực tiếp với công ty/sản phẩm/sự kiện. Không lấp bằng ảnh khái niệm chung.
- Cạnh dài nguồn ưu tiên ≥1200 px, hook cao ≥1400 px; ngoại lệ tư liệu ≥1000 px ghi rõ.
  Phân biệt độ phân giải nguồn và file cắt, không giả kích thước bằng upscale.
- Loại watermark, chữ chèn, ảnh ghép, screenshot, ảnh AI hoặc người bị nhận nhầm.
- Không lặp ảnh, bản crop của cùng ảnh hoặc buổi chụp đã dùng trong video cũ cùng người.
  Trong một video ưu tiên một ảnh/buổi; nếu hai ảnh thì đặt xa nhau. So aHash/MD5 và xem bằng mắt.
- Ghi `images/manifest.json`: file, URL ảnh, trang nguồn, tác giả, nguồn, giấy phép,
  kích thước gốc/file dùng, crop và hash. CC BY/BY-SA phải ghi công; ảnh báo chí giữ bản quyền
  phải ghi đúng tình trạng, không đổi thành giấy phép mở.
- Hook không được cắt mất mặt. Chỉnh crop, `hook_face_y`, hoặc đặt ảnh trên nền màu phù hợp.
  Thân dùng chính ảnh làm nền mờ, ảnh rõ pan/zoom tuyến tính và bóng đổ theo mẫu.

## 6. Mix nhạc theo thiết lập hiện tại

Gói kèm file nhạc do người dùng cung cấp tại `assets/music/fiction-vietz-remix.mp3`.
Điền đường dẫn đúng của file này vào `background_music.file` trong JSON dự án.
File MP3 giữ nguyên mức gốc; script mix áp dụng gain −17 dB một lần. Không lấy âm thanh Facebook làm nguồn.

```bash
python scripts/mix_audio.py work/videoNN/plan.json work/production/series-settings.json
```

Script đo/chuẩn hóa riêng lời đọc hai lượt, lấy nhạc từ `start_seconds`, giảm đúng `gain_db`,
fade, mix không tự normalize nhạc và ghi `mix-info.json`. Gắn `render_audio` và
`audio_mastered` vào plan để không chuẩn hóa lại nhạc ở render. Kiểm đo gain stem,
loudness cuối khoảng −16 LUFS (dung sai thực QA ±0,7), true peak ≤ −1,3 dBTP.

## 7. Preview, render và nghiệm thu

```bash
python scripts/render.py work/videoNN/plan.json work/videoNN/preview --preview --frames=0,60,120
python scripts/render_and_qa.py work/videoNN/plan.json outputs/See_The_Light_Nhan_vat_Chu_de.mp4
```

Preview thêm đầu từng shot; xem hook, toàn bộ khuôn mặt, chữ rõ và không đè mặt.
Render và QA chạy tuần tự trong cùng công việc; không kết thúc lượt bằng “đang render”.
`qa.py` phải báo **KẾT LUẬN: ĐẠT**: đúng định dạng, đủ lời, không karaoke trong hook,
có phụ đề ở mọi từ đang nói, lệch karaoke tối đa hai frame (≤67 ms), âm lượng đạt.
Mở `_qa_sheet.jpg` xem bằng mắt. Chưa đạt thì sửa và render lại; không giao bản lỗi.

## 8. Lưu và bàn giao

Chỉ sau QA và soát contact sheet:

```bash
python scripts/save_video.py outputs/See_The_Light_Nhan_vat_Chu_de.mp4 work/videoNN/qa.log work/production/series-settings.json --script-number N
```

Lưu theo `output_directory` mới nhất, không ghi đè bản có sẵn. So SHA-256 bản lưu với bản xuất,
ghi trạng thái vào settings. Giữ bản trung gian trong work và có thể bản phát ở outputs.
Bàn giao bằng tiếng Việt: video xem được, thời lượng, nhạc/mốc bắt đầu, đường dẫn Tải về,
kết quả QA (lệch karaoke, LUFS), từ/tên đã sửa, tác giả/giấy phép ảnh và chỗ còn phân vân.
Ghi rõ câu diễn ý và tình huống minh họa trong báo cáo nguồn. Không tự đăng video lên mạng xã hội.

## Cài đặt và phạm vi gói

Xem `README.md` để cài Python/ffmpeg, và `NOTICE.md` để biết nguồn, font/giấy phép.
Gói có tài liệu, scripts, template, font, phiên âm, danh sách chống trùng và bộ 40 kịch bản.
Có kèm bản nhạc FICTION – VIETZ REMIX do người dùng cung cấp. Không chứa tài khoản, token, cookie, giọng trả phí hoặc ảnh báo chí tải về.
Không phải mọi tệp được phép tái cấp giấy phép: giữ nguyên thông báo của nguồn tương ứng.
