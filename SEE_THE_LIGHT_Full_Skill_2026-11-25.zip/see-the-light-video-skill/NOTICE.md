# Xuất xứ và giấy phép

Quy trình gốc và phần lớn scripts/template được lấy từ skill người dùng đã nạp:
https://github.com/phamthevu15/sansan-video-bai-hoc

Hai luồng được gộp: `sansan-video-bai-hoc` và `kich-ban-bai-hoc-vbee`.
Bản tổng hợp bổ sung lựa chọn của người dùng trong bộ SEE THE LIGHT tháng 11-2026,
các điều chỉnh tương thích macOS đã dùng thực tế và helper mix/QA/lưu bản cuối.
Không tự áp một giấy phép MIT hoặc giấy phép mở mới lên mã/template của nguồn gốc
khi không có quyền tái cấp phép. Công khai repository không đồng nghĩa mọi thành phần
đều được tự do sử dụng. Giữ nguyên ghi công và thông báo của nguồn khi chia sẻ tiếp.

Font Inter: The Inter Project Authors, SIL Open Font License 1.1.
Giấy phép đầy đủ: `assets/fonts/Inter-OFL-LICENSE.txt`.

Font Be Vietnam Pro: Copyright 2021 The Be Vietnam Pro Project Authors
(https://github.com/bettergui/BeVietnamPro), SIL Open Font License 1.1.
Giấy phép đầy đủ: `assets/fonts/BeVietnamPro-OFL-LICENSE.txt`.
Đối chiếu từ nguồn Google Fonts:
https://github.com/google/fonts/blob/main/ofl/bevietnampro/OFL.txt

Nhạc FICTION – VIETZ REMIX và hình tư liệu của doanh nhân không được đóng trong gói.
Khi làm video, tiếp tục ghi tác giả/giấy phép từng ảnh trong manifest/báo cáo,
phân biệt ảnh phạm vi công cộng, CC BY/CC BY-SA và ảnh giữ bản quyền.

Các câu nói trong bộ 40 có nguồn được ghi theo từng bài. Hook Việt hóa/diễn ý
không được mô tả là nguyên văn; các tình huống minh họa không phải tiểu sử nhân vật.
