# Kiểm tra gói — 25-11-2026

- Skill frontmatter/naming: hợp lệ qua quick_validate.py.
- Cú pháp Python và JSON: hợp lệ.
- Tạo trang duyệt hook, JSON và bản TTS: thành công; bài thử có 132 tiếng/616 ký tự. Cảnh báo hook đã có trong danh sách chống trùng là đúng cho bài thử hiện hữu.
- Chạy lại mix → render → QA với bài 7 và media có sẵn tại máy, không đóng media đó vào gói công khai.
- Bản dựng: 1080 × 1920, 30 fps, H.264 High/yuv420p, AAC mono 48 kHz, 26,600 giây.
- Nhạc: từ 00:00, stem gain đo -17,000000 dB; không normalize nhạc/ducking.
- QA: ĐẠT. Karaoke lệch tối đa 45 ms; đầu câu 34 ms; -15,8 LUFS, true peak -1,6 dBTP; không karaoke trong hook, đủ phụ đề.
- Contact sheet đã xem bằng mắt.
- Lệnh lưu bản cuối chạy thử vào thư mục kiểm tra riêng và xác nhận SHA-256 bản lưu khớp bản xuất.
- SHA-256 video thử: 689adb17d642a6e82165f556d695ca7c62d378f448aef753353d5a596df08099.
- Kiểm tra tệp công khai: không có đường dẫn thư mục cá nhân, credential, cookie, môi trường ảo, cache/model, file nhạc hoặc giọng/video đã trả phí.

Kiểm tra pipeline dùng môi trường Python đã cài tại máy. Việc cài mới trên hệ điều hành khác còn phụ thuộc các bản thư viện, ffmpeg/libass và tải model lần đầu. Vbee cần phiên đăng nhập của người sử dụng.
