# SEE THE LIGHT — gói skill video trọn bộ

Bản tổng hợp 25-11-2026. Một gói gồm viết kịch bản, duyệt hook, tạo giọng Vbee,
bóc lời, căn từng từ, chọn ảnh thật, phụ đề karaoke, mix nhạc, render, QA và lưu MP4.

Đọc **[SKILL.md](SKILL.md)** để bắt đầu. Có thể giải nén thư mục này vào
`~/.codex/skills/see-the-light-video-skill/`, hoặc mở nó như một dự án và yêu cầu
trợ lý thực hiện đúng SKILL.md. Không cần cài các skill cũ riêng.

## Lựa chọn đã chốt

- Video dọc 25–30 giây; Ngọc Huyền 1.1x.
- Chủ đề nội tại, cuộc sống, sự nghiệp, tư duy công việc; hook tách riêng.
- Hook đỏ/ribbon SEE THE LIGHT, ảnh thật pan/zoom/nền mờ, karaoke IN HOA trắng → vàng.
- FICTION – VIETZ REMIX từ 00:00, −17 dB; không normalize nhạc hoặc ducking.
- Xuất 1080×1920, 30 fps; QA rồi lưu `~/Downloads/SEE THE LIGHT - Video` và so hash.

## Môi trường

Python 3.9 trở lên; Python 3.11/3.12 thường thuận tiện hơn khi cài gói mới.
Cài ffmpeg và ffprobe có libass/libx264 từ nguồn chính thức hoặc package manager.
Trên macOS có thể dùng `brew install ffmpeg`; Windows có `winget install Gyan.FFmpeg`.
Các trình cài và model không nằm trong gói ZIP.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/check_env.py
```

Windows dùng `.venv\Scripts\activate` thay lệnh `source`. Lần đầu Whisper/wav2vec
cần tải model; máy ít RAM chỉ chạy một tác vụ nặng một lúc. ASR mặc định dùng `small`;
karaoke vẫn căn riêng bằng wav2vec2 tiếng Việt, không lấy mốc Whisper.

## Chuẩn bị dự án

Từ thư mục dự án mới, tạo `work/production/series-settings.json` dựa trên file
`config/series-settings.example.json` trong gói. Điền đường dẫn **tuyệt đối** tới file nhạc
do người dùng cấp. Ví dụ JSON dùng đường dẫn tương đối thì script mix hiểu theo thư mục
làm việc hiện tại. Đặt `output_directory` theo máy đang chạy; `~` được script lưu mở rộng.

Đặt lời đọc tại `work/videoNN/voice.mp3`. Dùng `examples/config.example.json` làm mẫu,
đổi `audio` thành đường dẫn tuyệt đối, chọn đúng `person` và danh sách ảnh theo shot.
Các đường dẫn ảnh được tính từ thư mục chứa `plan.json`.

Lệnh đầy đủ theo thứ tự nằm trong SKILL.md. `render_and_qa.py` tạo log render/QA
trong thư mục plan. Xem contact sheet trước khi chạy `save_video.py`.

## Thành phần

- `SKILL.md`: một điểm vào chung, gồm toàn bộ bước và lựa chọn mới.
- `references/`: gu hook, Việt hóa, nhân vật, thân bài, Vbee, ảnh và thông số bố cục.
- `scripts/`: pipeline dựng đã dùng thực tế, cùng helper mix/QA/lưu bản cuối.
- `assets/`: template thương hiệu và font kèm giấy phép OFL.
- `examples/40-kich-ban-da-duyet.json`: bộ 40 bài hiện tại kèm nguồn và lời đọc.
- `data/`: phiên âm tên và danh sách chống trùng.
- `config/`: thiết lập portable, không có đường dẫn cá nhân hoặc lịch sử tài khoản.
- `NOTICE.md`: xuất xứ và giới hạn quyền của các thành phần.

Gói không chứa nhạc thương mại, ảnh báo chí, video/giọng đã trả phí, dữ liệu đăng nhập
hoặc môi trường Python/model cache. Người dùng cấp media và tài khoản khi chạy.
Việc đưa skill công khai không tự cấp quyền đăng lại các media đó.
